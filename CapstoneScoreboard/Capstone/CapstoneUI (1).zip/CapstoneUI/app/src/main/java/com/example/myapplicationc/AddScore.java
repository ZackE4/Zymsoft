package com.example.myapplicationc;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class AddScore extends AppCompatActivity {


RadioButton rd;
Score score;
TextView txt;
String text = " ";



    int scoreTemA = 0;
    int scoreTemB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_score);

       final RadioGroup team1 = findViewById(R.id.rdTeam1);
        final RadioGroup team2 = findViewById(R.id.rdTeam2);
        final RadioGroup addscore = findViewById(R.id.radioGroup);
      txt = (TextView) findViewById(R.id.textView5);
        final RadioButton radiobutton = (RadioButton) findViewById(R.id.radioButton);

                       score = new Score();


        












      /*  team2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
              
                boolean checked = ((RadioButton) view).isChecked();
                
                try{
                    if (team2.getCheckedRadioButtonId() == -1) {
                                         switch (view.getId)  {
                                             case R.id.radioButton:
                                                 if(checked)
                                                     score.setScore(1);
                                                      break;


                                             case R.id.radioButton2:
                                                 if(checked)
                                                     score.setScore(2);
                                                 break;




                                         }


                                         


                    }

                    else
                    {
                        team2.clearCheck();
                    }

                }
                catch (Exception ex)
                {

                }

            }
        });         */


        team1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                try{
                    if (team1.getCheckedRadioButtonId() == -1)
                    {

                    }
                    else
                    {
                        team1.clearCheck();
                    }
                }
                catch (Exception ex)
                {

                }

            }
        });
    }


    private void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.textView5);
        scoreView.setText(String.valueOf(score));
    }




    public void saveClose(View view) {

        finish();
    }

    public void addScore(View view) {
            boolean checked = ((RadioButton) view).isChecked();

            switch (view.getId()){
                case R.id.radioButton:
                    if(checked)
                        score.setScore(1);
                    text = "1";
                    break;
                case R.id.radioButton2:
                    if(checked)
                        score.setScore(2);
                    text = "2";
                case R.id.radioButton3:
                    if(checked)
                        score.setScore(3);
                    text= "3";
                    
            }
        
    }
}
