package com.example.myapplicationc;

public class Score {

double score = 0;

    public Score() {

    }

    public void setScore(double score) {
        this.score = score;
    }

    public double getScore() {
        return score;
    }

    public Score(double score) {
        this.score = score;
    }
}

