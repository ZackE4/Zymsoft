package com.example.myapplicationc;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final long START_TIME_IN_MILLIS = 3600000;
     MediaPlayer horn;

    private TextView mtextView;
    private Button mstart;
    private Button mreset;
    private Button mstop;
    private CountDownTimer mcountTimer;
    private  boolean mTimerRunning;
    private long mtimeLeftInMills = START_TIME_IN_MILLIS;
    int minteger = 0;
    int binterger = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


mtextView = findViewById(R.id.txtTimer);
mstart =findViewById(R.id.btnStart);
mstop = findViewById(R.id.btnstop);

mreset = findViewById(R.id.btnreset);
horn = MediaPlayer.create(MainActivity.this , R.raw.horn);

mstart.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if(mTimerRunning){
            pauseTimer();
        }
        else{
            startTimer();
        }

    }
});


mreset.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        resetTimer();

    }
});

updateCountDownText();


    }
    private void startTimer(){
        mcountTimer = new CountDownTimer(mtimeLeftInMills,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
mtimeLeftInMills= millisUntilFinished;
updateCountDownText();
            }


            @Override
            public void onFinish() {
mTimerRunning = false;
mstart.setText("Start");
mstart.setVisibility(View.INVISIBLE);
mstop.setVisibility(View.INVISIBLE);
mreset.setVisibility(View.VISIBLE);
            }
        }.start();

        mTimerRunning = true;
        mstart.setText("Stop");
        mreset.setVisibility(View.INVISIBLE);
        mstop.setVisibility(View.INVISIBLE);


    }
    private void resetTimer(){
        mtimeLeftInMills = START_TIME_IN_MILLIS;
        updateCountDownText();
        mreset.setVisibility(View.INVISIBLE);
        mstart.setVisibility(View.VISIBLE);
        mstop.setVisibility(View.VISIBLE);
        mreset.setVisibility(View.VISIBLE);

    }
    private void pauseTimer(){
        mcountTimer.cancel();
        mTimerRunning = false;
        mstart.setText("Start");
        mreset.setVisibility(View.VISIBLE);


    }
    private void updateCountDownText(){
        int minutes = (int) (mtimeLeftInMills/1000)/60;
        int seconds = (int) (mtimeLeftInMills/1000)%60;


        String timeLeftFormated  = String.format(Locale.getDefault(),"%02d:%02d", minutes,seconds);
   mtextView.setText(timeLeftFormated);

    }

    public void addScore(View view) {
        Intent intent = new Intent(this, AddScore.class);
        startActivity(intent);
    }

    public void addFouls(View view) {
        Intent intent = new Intent(this, AddFouls.class);
        startActivity(intent);
    }

    public void onminus(View view) {
        minteger = minteger-1;
        display(minteger);



    }
    public void onClickAdd(View view){
        minteger = minteger +1;
        display(minteger);

    }
    public void onminusB(View view) {
        binterger = binterger-1;
        displayB(binterger);



    }
    public void onClickAddB(View view){
        binterger = binterger +1;
        displayB(binterger);

    }

    public void onClickPlayHorn(View view){
        horn.start();

    }
    private void display(int number) {
        TextView displayInteger = (TextView) findViewById(
                R.id.textView15);
        displayInteger.setText("" + number);
    }
    private void displayB(int number) {

        TextView displayInter = (TextView)  findViewById(R.id.textView16);
        displayInter.setText("" + number);
    }


}
